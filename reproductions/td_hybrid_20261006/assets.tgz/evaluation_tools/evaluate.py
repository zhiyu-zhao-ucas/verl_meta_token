"""Use the frozen evaluator with each arm's historical DP checkpoint size."""

import argparse
import importlib.util
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("historical_evaluator", ROOT / "run_stage.py")
evaluator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(evaluator)


def checkpoint_check(model):
    actor = Path(model["source"])
    metadata = actor / "fsdp_config.json"
    if not metadata.is_file():
        return False, f"Missing {metadata}"
    world = model["world_size"]
    if evaluator.read(metadata)["world_size"] != world:
        raise RuntimeError(f"Checkpoint DP differs from historical DP{world}: {actor}")
    required = [actor / f"model_world_size_{world}_rank_{rank}.pt" for rank in range(world)]
    required += [actor / "huggingface/config.json", actor / "huggingface/tokenizer_config.json"]
    missing = [str(p) for p in required if not p.is_file() or not p.stat().st_size]
    return (False, f"Missing checkpoint files: {missing}") if missing else (True, str(actor))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--arm", choices=["td", "hybrid"], required=True)
    args, remaining = parser.parse_known_args()

    def readiness(stage, include_base=False):
        assert stage == "all" and not include_base
        pending = evaluator.training_readiness(args.arm)
        models = {
            name: model
            for name, model in evaluator.read(ROOT / "historical_models.json").items()
            if model["label"] == args.arm
        }
        assert set(models) == {f"{args.arm}_step_5", f"{args.arm}_step_10"}
        for name, model in models.items():
            ready, reason = checkpoint_check(model)
            if not ready:
                pending.append(f"{name}: {reason}")
        return models, pending

    evaluator.checkpoint_check = checkpoint_check
    evaluator.stage_readiness = readiness
    sys.argv = [sys.argv[0], *remaining]
    evaluator.main()
