"""Blocking single-GPU evaluations after the requested DP4 training arms exit."""
import argparse
import concurrent.futures
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
import queue
import subprocess
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPERIMENT = ROOT.parent
SOURCE = ROOT / 'source'
UV = '/tmp/verl-uv-bin/uv'
PYTHON = '/scratch2/zhiyu/miniconda3/envs/verl-delta-vllm-20260925/bin/python'
ALLOWLIST = set(range(8))
GPU_LOCK_DIR = Path("/tmp")
EXPORT_LOCK = threading.Lock()
STATE_LOCK = threading.Lock()
STATE = {}


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def update(name=None, **values):
    with STATE_LOCK:
        target = STATE.setdefault('models', {}).setdefault(name, {}) if name else STATE
        target.update(values)
        STATE['updated_at'] = time.strftime('%Y-%m-%dT%H:%M:%S%z')
        temporary = ROOT / f"stage_{STATE['stage']}_status.json.tmp"
        temporary.write_text(json.dumps(STATE, ensure_ascii=False, indent=2) + '\n')
        temporary.replace(ROOT / f"stage_{STATE['stage']}_status.json")


def validate_assets():
    revision = read(ROOT / 'assets_revision.json')
    for relative, expected in revision['files'].items():
        if sha(ROOT / relative) != expected:
            raise RuntimeError(f'Frozen evaluation asset changed: {relative}')
    protocol = read(ROOT / 'protocol.json')
    if protocol['physical_gpus'] != sorted(ALLOWLIST):
        raise RuntimeError('GPU allowlist changed')
    assert sha(ROOT / 'prompts.jsonl') == protocol['prompts_sha256']


def checkpoint_check(model):
    if model.get('step') == 0:
        actor = Path(model['source'])
        required = [actor / 'config.json', actor / 'tokenizer_config.json']
        if not all(path.is_file() for path in required) or not list(actor.glob('*.safetensors')):
            return False, f'Incomplete Base model assets: {actor}'
        return True, str(actor)
    actor = Path(model['source'])
    metadata = actor / 'fsdp_config.json'
    if not metadata.is_file():
        return False, f'missing {metadata}'
    world_size = read(metadata)['world_size']
    if world_size != 4:
        raise RuntimeError(f'Expected four-rank actor checkpoint, got {world_size}: {actor}')
    required = [actor / f'model_world_size_4_rank_{rank}.pt' for rank in range(4)]
    required += [actor / 'huggingface/config.json', actor / 'huggingface/tokenizer_config.json']
    missing = [str(p) for p in required if not p.is_file() or p.stat().st_size == 0]
    return (False, f'missing/empty checkpoint assets: {missing}') if missing else (True, str(actor))


def training_readiness(arm):
    run = EXPERIMENT / arm
    pending = []
    exit_code = run / 'exit_code'
    if not exit_code.is_file():
        pending.append(f'missing successful training exit marker: {exit_code}')
    elif int(exit_code.read_text()) != 0:
        raise RuntimeError(f'{arm} training failed: {exit_code.read_text().strip()}')
    metrics_path = run / 'metrics.jsonl'
    if not metrics_path.is_file():
        pending.append(f'missing training metrics: {metrics_path}')
    else:
        with metrics_path.open() as stream:
            metrics = [json.loads(line) for line in stream if line.strip()]
        if max((m.get('step', -1) for m in metrics), default=-1) < 10:
            pending.append(f'{arm} has not logged actor step10')
    manifest = run / 'manifest.json'
    if not manifest.is_file():
        pending.append(f'missing training manifest: {manifest}')
    else:
        training = read(manifest)
        paths = training['train_files']
        paths = paths if isinstance(paths, list) else [paths]
        expected = read(ROOT / 'provenance.json')['legacy_train_sha256']
        if len(paths) != 1 or sha(Path(paths[0])) != expected:
            raise RuntimeError('Training data differs from the frozen overlap audit')
        if training['actor'] != read(ROOT / 'protocol.json')['actor']:
            raise RuntimeError('Actor Base/tokenizer differs from frozen evaluation protocol')
    return pending


def stage_readiness(stage, include_base=False):
    arms = {'frozen': ['frozen'], 'refit': ['refit'], 'all': ['frozen', 'refit']}[stage]
    if include_base and stage == 'online':
        raise ValueError('Optional Base evaluation belongs to the frozen or all stage only')
    pending = [reason for arm in arms for reason in training_readiness(arm)]
    registry = read(ROOT / 'historical_models.json')
    expected = {f'{arm}_step_{step}' for arm in arms
                for step in [6, 10]}
    models = {k: v for k, v in registry.items() if v['label'] in arms}
    if set(models) != expected:
        raise RuntimeError(f'Unexpected evaluation model set: {sorted(models)}; expected {sorted(expected)}')
    if include_base:
        models['base_fast_step_0'] = registry['base_fast_step_0']
    for name, model in models.items():
        ready, reason = checkpoint_check(model)
        if not ready:
            pending.append(f'{name}: {reason}')
    return models, pending


def gpu_snapshot():
    command = ['nvidia-smi', '--query-gpu=index,uuid,memory.used', '--format=csv,noheader,nounits']
    snapshot, indices = {}, {}
    for row in subprocess.check_output(command, text=True, timeout=20).splitlines():
        index, uuid, memory = [x.strip() for x in row.split(',')]
        index = int(index)
        if index in ALLOWLIST:
            snapshot[index] = dict(memory_used_mib=int(memory), compute_pids=[])
            indices[uuid] = index
    command = ['nvidia-smi', '--query-compute-apps=gpu_uuid,pid', '--format=csv,noheader,nounits']
    for row in subprocess.check_output(command, text=True, timeout=20).splitlines():
        fields = [x.strip() for x in row.split(',')]
        if len(fields) == 2 and fields[0] in indices:
            snapshot[indices[fields[0]]]['compute_pids'].append(int(fields[1]))
    if set(snapshot) != ALLOWLIST:
        raise RuntimeError('Cannot inspect every GPU in 0–7')
    return snapshot


def wait_for_gpu(gpu, name):
    assert gpu in ALLOWLIST
    while True:
        usage = gpu_snapshot()[gpu]
        if not usage['compute_pids'] and usage['memory_used_mib'] <= 512:
            return
        update(name, state='waiting_for_gpu', gpu=gpu, gpu_usage=usage)
        time.sleep(30)



@contextmanager
def gpu_lease(gpus, name):
    """Choose any idle authorized card, locking and rechecking before inference."""
    while True:
        snapshot = gpu_snapshot()
        for gpu in gpus:
            usage = snapshot[gpu]
            if usage['compute_pids'] or usage['memory_used_mib'] > 512:
                continue
            with (GPU_LOCK_DIR / f'delta_old4_evaluation_gpu_{gpu}.lock').open('a+') as lock:
                try:
                    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    continue
                try:
                    # Another process may have occupied the card since the first snapshot.
                    usage = gpu_snapshot()[gpu]
                    if usage['compute_pids'] or usage['memory_used_mib'] > 512:
                        continue
                    yield gpu
                    return
                finally:
                    fcntl.flock(lock, fcntl.LOCK_UN)
        update(name, state='waiting_for_gpu', requested_gpus=gpus, gpu_snapshot=snapshot)
        time.sleep(30)

def wait_for_memory(name):
    while True:
        available = next(int(line.split()[1]) / 1024**2 for line in Path('/proc/meminfo').read_text().splitlines()
                         if line.startswith('MemAvailable:'))
        if available >= 128:
            return
        update(name, state='waiting_for_host_memory', available_gib=available)
        time.sleep(30)


def execute(script, arguments, name, gpu=''):
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(gpu), PYTHONPATH=str(SOURCE),
               OMP_NUM_THREADS='2', TOKENIZERS_PARALLELISM='false', HF_HUB_OFFLINE='1',
               HF_DATASETS_OFFLINE='1', TRANSFORMERS_OFFLINE='1', VLLM_WORKER_MULTIPROC_METHOD='spawn')
    env.pop('RAY_ADDRESS', None)
    stamp = time.time_ns()
    logfile = ROOT / 'logs' / f'{name}_{Path(script).stem}_{stamp}.log'
    logfile.parent.mkdir(exist_ok=True)
    command = [UV, 'run', '--python', PYTHON, '--no-project', 'python', str(ROOT / script), *arguments]
    with logfile.open('x') as log:
        result = subprocess.run(command, cwd=SOURCE, env=env, stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f'{name}: {script} exited {result.returncode}; log={logfile}')


def complete(name):
    path = ROOT / name / 'summary.json'
    if not path.is_file():
        return False
    summary = read(path)
    if len(summary.get('repository_main_eval_crosschecks', {})) != 2:
        return False
    return all(summary['full_8192'][dataset]['scores']['training_compatible']['total_responses'] == count * 16
               for dataset, count in read(ROOT / 'protocol.json')['dataset_counts'].items())


def worker(gpus, jobs):
    while True:
        try:
            name, model = jobs.get_nowait()
        except queue.Empty:
            return
        try:
            if complete(name):
                update(name, state='complete', reused=True)
                continue
            folder = ROOT / name
            generation = read(folder / 'status.json') if (folder / 'status.json').exists() else {}
            if generation.get('state') != 'generated':
                if (folder / 'generations.jsonl').exists():
                    raise RuntimeError(f'{name} has partial generations; refusing to overwrite')
                if model['step']:
                    with EXPORT_LOCK:
                        wait_for_memory(name)
                        update(name, state='exporting')
                        execute('prepare.py', ['--export', str(model['step']), '--run', model['run'], '--name', name], name)
                with gpu_lease(gpus, name) as gpu:
                    update(name, state='generating', gpu=gpu)
                    execute('generate.py', ['--step', str(model['step']), '--name', name], name, gpu)
                generation = read(folder / 'status.json')
            if generation.get('state') != 'generated' or generation.get('completed_responses') != 11008:
                raise RuntimeError(f'Incomplete generation: {name}')
            if (folder / 'scored.jsonl').exists():
                raise RuntimeError(f'{name} has incomplete scoring artifacts; refusing to overwrite')
            update(name, state='scoring')
            execute('audit.py', ['--step', str(model['step']), '--name', name], name)
            if not complete(name):
                raise RuntimeError(f'Incomplete scorer crosschecks: {name}')
            update(name, state='complete')
        except Exception as exc:
            update(name, state='failed', error=repr(exc))
            raise
        finally:
            jobs.task_done()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['frozen', 'refit', 'all'], required=True)
    parser.add_argument('--gpus', default='0,1,2,3')
    parser.add_argument('--include-base', action='store_true', help='Opt in to an additional Base0 evaluation; disabled by default')
    parser.add_argument('--check', action='store_true', help='Read-only readiness inspection; no waiting or evaluation')
    parser.add_argument('--parallel-online', action='store_true', help='Run the online arm beside an active frozen stage')
    args = parser.parse_args()
    if args.parallel_online and args.stage != 'online':
        parser.error('--parallel-online requires --stage online')
    requested_gpus = [int(value) for value in args.gpus.split(',')]
    gpus = requested_gpus
    assignment_path = EXPERIMENT / 'evaluation_gpu_assignment.json'
    if args.stage == 'all' and assignment_path.is_file():
        assignment = read(assignment_path)
        assigned_gpus = assignment.get('assigned_gpus')
        if assignment.get('stage') != 'all':
            raise RuntimeError(f'Unexpected evaluation GPU assignment: {assignment_path}')
        if requested_gpus == assignment.get('scheduler_requested_gpus'):
            gpus = assigned_gpus
        elif requested_gpus != assigned_gpus:
            raise RuntimeError(f'Unexpected evaluation GPU request: {requested_gpus}')
    if not gpus or len(set(gpus)) != len(gpus) or not set(gpus) <= ALLOWLIST:
        parser.error('GPU list must be a nonempty unique subset of 0,1,2,3,4,5,6,7')
    validate_assets()
    models, pending = stage_readiness(args.stage, include_base=args.include_base)
    if args.check:
        print(json.dumps(dict(stage=args.stage, ready=not pending, pending=pending,
                              models=list(models), requested_gpus=requested_gpus, gpus=gpus,
                              gpu_snapshot=gpu_snapshot(), launched=False), indent=2))
        return
    if pending:
        raise RuntimeError('Evaluation stage is not ready: ' + '; '.join(pending))
    lock_name = 'stage_online_parallel.lock' if args.parallel_online else 'stage.lock'
    with (ROOT / lock_name).open('a+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        STATE.update(stage=args.stage, pid=os.getpid(), state='evaluating',
                     requested_gpus=requested_gpus, gpus=gpus, models={})
        update(started_at=time.strftime('%Y-%m-%dT%H:%M:%S%z'))
        jobs = queue.Queue()
        for item in models.items():
            jobs.put(item)
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=min(len(gpus), len(models))) as pool:
                futures = [pool.submit(worker, gpus, jobs) for _ in range(min(len(gpus), len(models)))]
                for future in concurrent.futures.as_completed(futures):
                    future.result()
            if not all(complete(name) for name in models):
                raise RuntimeError('Some requested models did not complete')
            update(state='complete', completed_at=time.strftime('%Y-%m-%dT%H:%M:%S%z'))
            print(json.dumps(dict(stage=args.stage, state='complete', models=list(models))))
        except Exception as exc:
            update(state='failed', error=repr(exc))
            raise


if __name__ == '__main__':
    main()
