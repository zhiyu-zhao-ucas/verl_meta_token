# Copyright 2026 Individual Contributor: zhiyu
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Build the length-capped (<= p95 row width) training subset for the 4B critic.

Why: `collate()` right-pads every rank's rows to the longest row that rank holds,
and the collection is violently bimodal — 18 rows sit at the 30,720 generation
cap and alone carry 50.2% of all tokens. A single cap-length row drags a whole
micro-batch to ~31k width, which OOM'd at microbatch 8 and left only ~2.7 GiB
headroom at microbatch 8 with the allocator fixed. Capping row width at the 95th
percentile (7,925 tokens) drops the longest 26 rollouts and takes the worst-case
micro-batch width from 31,000 to 7,786.

What that costs, measured on the real label pipeline (see the report this writes):
target tokens -63.9%, but TD labels (selected states) -16.2% and continuations
-16.2%, because state selection saturates at `states_per_response: 64` and every
row >= ~2048 tokens already yields the full 64 states x 16 continuations. The
critic loses long-horizon context, not proportional supervision.

`rank_eval` is deliberately NOT filtered: the final evaluation should stay on the
natural length distribution.

    PYTHONPATH=. python outputs/delta_qwen3_4b_base_dapo_20260927/train/make_p95_subset.py
"""

import json
from pathlib import Path

from examples.delta_critic.legacy_adapter import adapt_legacy_rows
from examples.delta_critic.train import read_rows

RUN = Path(__file__).resolve().parents[1]
DATA = RUN / "data"
OUT = Path(__file__).resolve().parent / "data_p95"
HOLDOUT_FRACTION = 0.1
QUANTILE = 0.95
STREAMED = {
    "continuations_train.jsonl": "rollout_id",
    "mc_labels_train.jsonl": "rollout_id",
    "rollouts_train_regen.jsonl": "id",
}


def width_of(row):
    return len(row["prompt_token_ids"]) + len(row["response_token_ids"])


def quantile(values, q):
    """Linear-interpolation quantile, matching numpy's default without the import."""
    ordered = sorted(values)
    pos = q * (len(ordered) - 1)
    low = int(pos)
    high = min(low + 1, len(ordered) - 1)
    return ordered[low] + (ordered[high] - ordered[low]) * (pos - low)


def main():
    rollouts = read_rows(DATA / "rollouts_train_regen.jsonl")
    widths = {str(row["id"]): width_of(row) for row in rollouts}
    if len(widths) != len(rollouts):
        raise RuntimeError("Duplicate rollout IDs in the source train file")

    cutoff = quantile(list(widths.values()), QUANTILE)
    keep = {rid for rid, width in widths.items() if width <= cutoff}
    dropped = sorted(set(widths) - keep, key=lambda rid: -widths[rid])

    OUT.mkdir(parents=True, exist_ok=True)
    OUT.joinpath("cutoff.json").write_text(
        json.dumps({"quantile": QUANTILE, "cutoff_tokens": cutoff}, indent=2) + "\n"
    )
    for filename, key in STREAMED.items():
        kept = 0
        with (DATA / filename).open() as source, (OUT / filename).open("w") as sink:
            for line in source:
                if not line.strip():
                    continue
                if str(json.loads(line)[key]) in keep:
                    sink.write(line)
                    kept += 1
            print(f"{filename}: kept {kept}")

    # Split by file order over the kept pool, same positional-tail policy as the
    # full-data split, so the two runs remain directly comparable.
    filtered = read_rows(OUT / "rollouts_train_regen.jsonl")
    file_order = [str(row["id"]) for row in filtered]
    examples, _ = adapt_legacy_rows(filtered, read_rows(OUT / "mc_labels_train.jsonl"))
    if {e.rollout.rollout_id for e in examples} != set(file_order):
        raise RuntimeError("Adapter ID set does not match the filtered file; split would be rejected")

    eval_len = max(1, int(len(file_order) * HOLDOUT_FRACTION))
    split_map = {
        rid: ("eval" if index >= len(file_order) - eval_len else "train")
        for index, rid in enumerate(file_order)
    }
    if set(split_map.values()) != {"train", "eval"}:
        raise RuntimeError("Split must map every rollout to exactly one of train or eval")
    (OUT / "split.json").write_text(json.dumps(split_map, indent=2, sort_keys=True) + "\n")

    full_tokens = sum(widths.values())
    keep_tokens = sum(widths[rid] for rid in keep)
    report = {
        "cutoff": {"quantile": QUANTILE, "cutoff_tokens": cutoff},
        "rollouts": {"total": len(widths), "kept": len(keep), "dropped": len(dropped)},
        "tokens": {
            "total": full_tokens,
            "kept": keep_tokens,
            "dropped_fraction": round(1 - keep_tokens / full_tokens, 4),
            "max_kept_row": max(widths[rid] for rid in keep),
        },
        "split": {"rows": len(file_order), "train": len(split_map) - eval_len, "eval": eval_len},
        "note": "rank_eval intentionally left unfiltered for natural-distribution evaluation",
    }
    (OUT / "subset_report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
