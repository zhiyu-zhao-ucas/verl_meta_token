"""Run the restored trainer unchanged; stop its loop after ten full steps."""

import argparse
import json
import os
from pathlib import Path

import ray
from omegaconf import OmegaConf

ROOT = Path(__file__).resolve().parent


@ray.remote
class HistoricalTaskRunner:
    def run(self, config):
        import transfer_queue as tq
        from prompt_audit import digest

        from verl.trainer.ppo.v1 import AgentLoopManagerTQ, get_trainer_cls
        from verl.utils.logging_utils import configure_verl_logging
        from verl.utils.tokenizer.continuous_token_wiring import create_continuous_token_builder

        configure_verl_logging()
        config.transfer_queue.enable = True
        OmegaConf.resolve(config)
        tq.init(config.transfer_queue)
        trainer = None
        succeeded = False
        try:
            trainer = get_trainer_cls(config.trainer.v1.trainer_mode)(config=config)
            trainer.init()
            branch = Path(config.trainer.default_local_dir).parent
            assert trainer.global_steps == 0
            horizon = int(trainer.total_training_steps)
            optimizer_horizon = int(config.actor_rollout_ref.actor.optim.total_training_steps)
            assert horizon == int(config.trainer.total_training_steps)
            # Optimizers have already been initialized with the original horizon.
            # Only the loop cap changes; the saved training config remains historical.
            trainer.total_training_steps = 10
            (branch / "runtime_schedule.json").write_text(
                json.dumps(
                    dict(
                        historical_training_horizon=horizon,
                        optimizer_horizon=optimizer_horizon,
                        loop_stop_step=10,
                        source_module=__import__("verl").__file__,
                    ),
                    indent=2,
                )
                + "\n"
            )
            audit = json.loads((branch / "prompt_audit.json").read_text())
            builder = create_continuous_token_builder(
                trainer.tokenizer,
                hf_model_type="qwen3",
                chat_template_kwargs=OmegaConf.to_container(config.data.apply_chat_template_kwargs),
            )
            original_submit = trainer._submit_batch_to_rollout

            def checked_submit(batch):
                step = str(trainer.global_steps)
                token_hashes = [
                    digest(
                        builder.build_initial_tokens(list(messages))[-config.actor_rollout_ref.rollout.prompt_length :]
                    )
                    for messages in batch["raw_prompt"]
                ]
                expected = audit["ordered_training_prompt_schedule"][step]["token_hashes"]
                assert token_hashes == expected, f"Ordered model prompt inputs differ at step {step}"
                with (branch / "runtime_prompt_checks.jsonl").open("a") as stream:
                    stream.write(
                        json.dumps(
                            dict(
                                step=int(step),
                                ordered_prompt_tokens_equal=True,
                                prompt_count=len(token_hashes),
                                prompt_hashes=token_hashes,
                            )
                        )
                        + "\n"
                    )
                return original_submit(batch)

            trainer._submit_batch_to_rollout = checked_submit
            assert not config.actor_rollout_ref.rollout.agent.get("agent_loop_manager_class")
            manager = AgentLoopManagerTQ.create(
                config=config,
                llm_client=trainer.get_llm_client(),
                teacher_client=trainer.get_teacher_client(),
                reward_loop_worker_handles=trainer.get_reward_handles(),
            )
            trainer.fit(manager)
            succeeded = True
        finally:
            try:
                tracking = getattr(trainer, "logger", None)
                if tracking is not None:
                    tracking.finish(exit_code=0 if succeeded else 1)
            finally:
                tq.close()


def main(arm):
    from verl.trainer.main_ppo import run_ppo

    branch = ROOT / arm
    config = OmegaConf.load(branch / "config.yaml")
    visible = os.environ["CUDA_VISIBLE_DEVICES"].split(",")
    assert len(set(visible)) == len(visible) == config.trainer.n_gpus_per_node
    assert not (branch / "checkpoints/delta_advantage_stats.json").exists()
    try:
        run_ppo(config, HistoricalTaskRunner)
    finally:
        ray.shutdown()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--arm", choices=["td", "hybrid"], required=True)
    main(parser.parse_args().arm)
