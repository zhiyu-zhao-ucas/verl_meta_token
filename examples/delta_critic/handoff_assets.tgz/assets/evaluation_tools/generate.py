"""Independent, seeded vLLM sampling. One process owns one physical GPU."""
import argparse
import hashlib
import json
import os
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--step', type=int, required=True)
    parser.add_argument('--name')
    args = parser.parse_args()
    from vllm import LLM, SamplingParams
    from transformers import AutoTokenizer
    from verl.utils.tokenizer.tokenizer import normalize_token_ids

    protocol = json.loads((ROOT / 'protocol.json').read_text())
    rows = [json.loads(line) for line in (ROOT / 'prompts.jsonl').read_text().splitlines()]
    name = args.name or f'step_{args.step}'
    model = protocol['actor'] if args.step == 0 else str(ROOT / 'models' / name)
    training_overlap = None
    if args.name:
        registry = json.loads((ROOT / 'historical_models.json').read_text())
        training_overlap = set(registry[name]['overlapping_prompt_indices'])
    if args.step:
        assert (Path(model) / 'EXPORT_VALIDATED.json').is_file()
    tokenizer = AutoTokenizer.from_pretrained(model, local_files_only=True)
    for row in rows:
        assert row['prompt_token_ids'] == normalize_token_ids(tokenizer.apply_chat_template(
            row['prompt'], add_generation_prompt=True, enable_thinking=True))
    inference = dict(protocol['inference'])
    batch_size = 16
    profile_id = 'original_v1'
    acceleration = ROOT / 'accelerated_inference.json'
    if args.name and acceleration.exists():
        profile = json.loads(acceleration.read_text())
        if profile['enabled'] and name in profile['models']:
            assert profile.get('validation', {}).get('passed') is True
            allowed = {'max_model_len', 'max_num_seqs', 'enforce_eager',
                       'enable_prefix_caching', 'compilation_config'}
            assert set(profile['inference_overrides']) <= allowed
            inference.update(profile['inference_overrides'])
            batch_size = profile['prompt_batch_size']
            assert isinstance(batch_size, int) and batch_size >= 16
            assert inference['max_model_len'] >= max(len(r['prompt_token_ids']) for r in rows) + 8192
            profile_id = profile['profile_id']
    folder = ROOT / name
    folder.mkdir(exist_ok=True)
    output = folder / 'generations.jsonl'
    assert not output.exists(), 'Refusing to overwrite prior generations'
    provenance = dict(profile_id=profile_id, inference=inference,
                      prompt_batch_size=batch_size, sampling=protocol['sampling'],
                      prompts_sha256=protocol['prompts_sha256'],
                      generation_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                      note='Batching and kernel changes may change individual outputs despite fixed seeds.')
    provenance_path = folder / 'inference_profile.json'
    with provenance_path.open('x') as stream:
        stream.write(json.dumps(provenance, indent=2)+'\n')
    engine = LLM(model=model, tokenizer=model, seed=42, **inference)
    start = time.time()
    status = dict(step=args.step, model_name=name, physical_gpu=os.environ['CUDA_VISIBLE_DEVICES'],
                  pid=os.getpid(), state='generating', inference_profile=profile_id, total_prompts=len(rows),
                  total_responses=len(rows)*16, started_at=time.strftime('%Y-%m-%dT%H:%M:%S%z'))
    def update(**kwargs):
        status.update(kwargs)
        status['elapsed_seconds'] = time.time()-start
        temporary = folder / 'status.json.tmp'
        temporary.write_text(json.dumps(status, indent=2)+'\n')
        temporary.replace(folder / 'status.json')
        print(json.dumps(status), flush=True)
    update(completed_prompts=0, completed_responses=0)
    with output.open('x') as stream:
        for offset in range(0, len(rows), batch_size):
            block = rows[offset:offset+batch_size]
            prompts, params = [], []
            identities = []
            for i, row in enumerate(block, start=offset):
                for sample in range(16):
                    seed = 42 + i*16 + sample
                    prompts.append(dict(prompt_token_ids=row['prompt_token_ids']))
                    params.append(SamplingParams(temperature=1.0, top_p=1.0, top_k=-1, min_p=0.0,
                                                 n=1, seed=seed, max_tokens=8192,
                                                 repetition_penalty=1.0, presence_penalty=0.0,
                                                 frequency_penalty=0.0, ignore_eos=False))
                    identities.append((row, i, sample, seed))
            results = engine.generate(prompts, params, use_tqdm=True)
            assert len(results) == len(identities)
            for request, (row, index, sample, seed) in zip(results, identities, strict=True):
                assert list(request.prompt_token_ids) == row['prompt_token_ids']
                assert len(request.outputs) == 1
                response = request.outputs[0]
                record = {k:v for k,v in row.items() if k not in ['prompt_token_ids', 'prompt_text']}
                record.update(step=args.step, prompt_index=index, sample_index=sample, seed=seed,
                              model_name=name, inference_profile=profile_id,
                              output=response.text, output_token_ids=list(response.token_ids),
                              output_2048=tokenizer.decode(response.token_ids[:2048], skip_special_tokens=True),
                              output_tokens=len(response.token_ids), finish_reason=response.finish_reason,
                              stop_reason=response.stop_reason, truncated_8192=response.finish_reason == 'length',
                              truncated_2048=len(response.token_ids) > 2048)
                if training_overlap is not None:
                    record['exact_training_prompt_overlap'] = index in training_overlap
                stream.write(json.dumps(record, ensure_ascii=False)+'\n')
            stream.flush()
            os.fsync(stream.fileno())
            update(completed_prompts=offset+len(block), completed_responses=(offset+len(block))*16)
    update(state='generated')


if __name__ == '__main__':
    main()
