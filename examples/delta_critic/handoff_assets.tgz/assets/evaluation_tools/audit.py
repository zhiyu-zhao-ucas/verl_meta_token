"""Score persisted responses independently and report per-dataset pass@k."""
import argparse
import hashlib
import collections
import concurrent.futures
import json
import multiprocessing
import os
import re
import subprocess
import sys
from pathlib import Path
from scorers import score_output

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'source'))


def score_row(row):
    result = dict(row)
    result['evaluation_8192'] = score_output(row['output'], row['gold'])
    result['evaluation_2048_prefix'] = (score_output(row['output_2048'], row['gold'])
        if row['output_tokens'] > 2048 else result['evaluation_8192'])
    return result


def summarize(rows, key):
    result = {}
    groups = collections.defaultdict(list)
    for row in rows:
        groups[row['dataset']].append(row)
        if row.get('original_math100'):
            groups['math500_original100'].append(row)
    for dataset, group in groups.items():
        by_prompt = collections.defaultdict(list)
        for row in group:
            by_prompt[row['id']].append(row)
        assert all(len(items) == 16 for items in by_prompt.values())
        scores = {}
        for name in group[0][key]['scores']:
            correct = sum(row[key]['scores'][name] for row in group)
            solved = sum(any(row[key]['scores'][name] for row in items) for items in by_prompt.values())
            scores[name] = dict(correct_responses=int(correct), total_responses=len(group),
                                mean_accuracy=correct / len(group), pass_at_1=correct / len(group),
                                prompts_with_any_correct=solved, total_prompts=len(by_prompt),
                                pass_at_16=solved / len(by_prompt))
        result[dataset] = dict(scores=scores,
            exact_training_overlap_prompts=sum(any(r['exact_training_prompt_overlap'] for r in items)
                                              for items in by_prompt.values()),
            mean_output_tokens=sum(r['output_tokens'] for r in group)/len(group),
            length_limit_count=sum(r['truncated_8192'] for r in group),
            prefix_cut_count=sum(r['truncated_2048'] for r in group),
            missing_final_count=sum(r[key]['extracted_final'] is None for r in group),
            scoring_disagreements=sum(r[key]['scoring_disagreement'] for r in group),
            scorer_error_count=sum(bool(r[key]['scorer_errors']) for r in group))
    return result


def main():
    import pandas as pd
    parser = argparse.ArgumentParser()
    parser.add_argument('--step', type=int, required=True)
    parser.add_argument('--name')
    parser.add_argument('--smoke', action='store_true')
    args = parser.parse_args()
    name = args.name or f'step_{args.step}'
    folder = ROOT / name
    # JSON strings may contain Unicode line separators; only physical JSONL
    # newlines delimit records.
    with (folder / 'generations.jsonl').open() as stream:
        rows = [json.loads(line) for line in stream]
    expected = sum(json.loads((ROOT / 'protocol.json').read_text())['dataset_counts'].values()) * 16
    if args.smoke:
        expected = 64
    assert len(rows) == expected, (len(rows), expected)
    scored = []
    with concurrent.futures.ProcessPoolExecutor(max_workers=8, mp_context=multiprocessing.get_context('spawn')) as pool:
        with (folder / 'scored.jsonl').open('x') as stream, (folder / 'disagreements.jsonl').open('x') as disagreement:
            for i, row in enumerate(pool.map(score_row, rows, chunksize=16), start=1):
                stream.write(json.dumps(row, ensure_ascii=False)+'\n')
                if row['evaluation_8192']['scoring_disagreement'] or row['evaluation_8192']['scorer_errors']:
                    disagreement.write(json.dumps(row, ensure_ascii=False)+'\n')
                scored.append(row)
                if i % 256 == 0:
                    print(f'Scored step {args.step}: {i}/{expected}', flush=True)
    summary = dict(step=args.step, model_name=name, samples_per_prompt=16, temperature=1.0,
                   full_8192=summarize(scored, 'evaluation_8192'),
                   prefix_2048_diagnostic=summarize(scored, 'evaluation_2048_prefix'))
    profile_path = folder / 'inference_profile.json'
    summary['inference_profile'] = (json.loads(profile_path.read_text()) if profile_path.exists()
        else dict(profile_id='original_v1', inference=json.loads((ROOT/'protocol.json').read_text())['inference'],
                  prompt_batch_size=16))
    (folder / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    by_prompt = collections.defaultdict(list)
    for row in rows:
        by_prompt[(row['dataset'], row['id'])].append(row)
    parquet = [dict(data_source=ds, prompt=items[0]['prompt'],
                    reward_model=dict(ground_truth=items[0]['gold']),
                    responses=[r['output'] for r in sorted(items, key=lambda r:r['sample_index'])])
               for (ds, uid), items in by_prompt.items()]
    pd.DataFrame(parquet).to_parquet(folder / 'responses.parquet')
    # Exercise the repository's dedicated evaluator as well as the per-row audit.
    # main_eval's old config still exposes root custom_reward_function, whereas
    # get_custom_reward_fn reads config.reward; provide the nested setting explicitly.
    checks = {}
    for name, function in [('repository_math_verify', 'offline_repository_math_verify'),
                           ('explicit_final_math_verify', 'offline_explicit_final')]:
        session_hash = hashlib.sha256((str(folder)+name).encode()).hexdigest()[:12]
        command = ['/tmp/verl-uv-bin/uv', 'run', '--python',
                   '/scratch2/zhiyu/miniconda3/envs/verl-delta-vllm-20260925/bin/python', '--no-project',
                   'python', '-m', 'verl.trainer.main_eval', f'data.path={folder / "responses.parquet"}',
                   f'+reward.custom_reward_function.path={ROOT / "scorers.py"}',
                   f'+reward.custom_reward_function.name={function}', 'ray_kwargs.ray_init.num_cpus=8',
                   '+ray_kwargs.ray_init.num_gpus=0', '+ray_kwargs.ray_init.object_store_memory=134217728',
                   '+ray_kwargs.ray_init.include_dashboard=false',
                   f'+ray_kwargs.ray_init._temp_dir=/tmp/ie-{session_hash}']
        log_path = folder / f'main_eval_{name}.log'
        with log_path.open('x') as log:
            subprocess.run(command, cwd=ROOT / 'source', stdout=log, stderr=subprocess.STDOUT, check=True,
                           env=dict(os.environ,PYTHONPATH=str(ROOT / 'source')))
        text = log_path.read_text()
        matches = dict(re.findall(r"'test_score/([^']+)': np\.float64\(([\deE+.-]+)\)", text))
        assert matches, f'No main_eval metrics found in {log_path}'
        for dataset in ['dapo_holdout', 'math500', 'aime2024', 'aime2025']:
            assert abs(float(matches[dataset]) - summary['full_8192'][dataset]['scores'][name]['mean_accuracy']) < 1e-12
        checks[name] = dict(command=command, scores={k:float(v) for k,v in matches.items()},
                           matches_per_row_audit=True)
    summary['repository_main_eval_crosschecks'] = checks
    (folder / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    # Reporting is serialized by a lock because the two supervisors may score
    # independent checkpoints at the same time.
    import fcntl
    from report import update_report
    with (ROOT / 'report.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        update_report()
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == '__main__':
    main()
