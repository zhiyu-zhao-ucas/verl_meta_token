"""Materialize complete results and a compact table; never label partial data complete."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def update_report():
    names = []
    if (ROOT / 'historical_models.json').exists():
        registry = json.loads((ROOT / 'historical_models.json').read_text())
        names += [name for name, model in registry.items()
                  if not model.get('optional', False) or (ROOT / name / 'summary.json').exists()]
    complete, pending = {}, []
    for name in names:
        path = ROOT / name / 'summary.json'
        if not path.exists():
            pending.append(name)
            continue
        result = json.loads(path.read_text())
        if len(result.get('repository_main_eval_crosschecks', {})) != 2:
            pending.append(name)
            continue
        complete[name] = result
    payload = dict(state='complete' if not pending else 'partial', total_models=len(names),
                   completed_models=list(complete), pending_models=pending, results=complete)
    temporary = ROOT / 'results.json.tmp'
    temporary.write_text(json.dumps(payload,indent=2)+'\n')
    temporary.replace(ROOT / 'results.json')
    fieldnames = ['model','step','dataset','budget','scorer','pass_at_1','pass_at_16',
                  'correct_responses','total_responses','prompts_with_any_correct','total_prompts',
                  'length_limit_count','prefix_cut_count','missing_final_count',
                  'scoring_disagreements','scorer_error_count','exact_training_overlap_prompts']
    table = ROOT / 'results.csv.tmp'
    with table.open('w', newline='') as stream:
        writer = csv.DictWriter(stream,fieldnames=fieldnames)
        writer.writeheader()
        for name,result in complete.items():
            for budget in ['full_8192','prefix_2048_diagnostic']:
                for dataset,metrics in result[budget].items():
                    for scorer,scores in metrics['scores'].items():
                        row = dict(model=name,step=result['step'],dataset=dataset,budget=budget,scorer=scorer,
                                   **{k:v for k,v in scores.items() if k != 'mean_accuracy'})
                        row.update({k:metrics[k] for k in fieldnames if k in metrics})
                        writer.writerow(row)
    table.replace(ROOT / 'results.csv')
    return payload


if __name__ == '__main__':
    result=update_report()
    print(json.dumps({k:v for k,v in result.items() if k != 'results'},indent=2))
