"""Freeze evaluation data and export inference weights with the repository merger."""
import argparse
import hashlib
import json
import os
import shutil
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[2]
RUN = ROOT.parent / 'f_td'


def dump(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')


def get_json(url, **params):
    with urllib.request.urlopen(url + '?' + urllib.parse.urlencode(params), timeout=45) as response:
        return json.load(response)


def prepare_data():
    import pandas as pd
    from datasets import Dataset
    from transformers import AutoTokenizer
    from verl.utils.reward_score.math_dapo import normalize_final_answer
    from verl.utils.tokenizer.tokenizer import normalize_token_ids

    ROOT.mkdir(exist_ok=True)
    raw = ROOT / 'raw_datasets'
    raw.mkdir(exist_ok=True)
    manifest = json.loads((RUN / 'manifest.json').read_text())
    tokenizer = AutoTokenizer.from_pretrained(manifest['actor'], local_files_only=True)
    validation = pd.read_parquet(manifest['val_files'])
    records = []
    for row in validation[validation.data_source == 'dapo_holdout'].to_dict('records'):
        records.append(dict(dataset='dapo_holdout', id=str(row['extra_info']['index']),
                            prompt=list(row['prompt']), gold=str(row['reward_model']['ground_truth'])))
    math_path = next(Path('/scratch2/zhiyu/.cache/huggingface/datasets/HuggingFaceH4___math-500').rglob('*test.arrow'))
    math = Dataset.from_file(str(math_path))
    assert len(math) == 500
    previous_math = validation[validation.data_source == 'math500'].reset_index(drop=True)
    for i, row in enumerate(math):
        if i < 100:
            assert previous_math.iloc[i]['prompt'][0]['content'] == row['problem']
            assert previous_math.iloc[i]['reward_model']['ground_truth'] == row['answer']
        records.append(dict(dataset='math500', id=str(row['unique_id']),
                            prompt=[dict(role='user', content=row['problem'])], gold=str(row['answer']),
                            original_math100=i < 100, subject=row['subject'], level=row['level']))
    sources = {'math500': str(math_path), 'dapo_holdout': manifest['val_files']}
    for name, source in [('aime2024', 'HuggingFaceH4/aime_2024'), ('aime2025', 'opencompass/AIME2025')]:
        raw_path = raw / (name + '.json')
        if raw_path.exists():
            entries = json.loads(raw_path.read_text())
        else:
            info = get_json('https://huggingface.co/api/datasets/' + source)
            entries = []
            files = [item['rfilename'] for item in info['siblings']
                     if item['rfilename'].endswith(('.parquet', '.jsonl'))]
            for filename in files:
                local = raw / (name + '_' + Path(filename).name)
                url = f"https://huggingface.co/datasets/{source}/resolve/{info['sha']}/{filename}"
                if not local.exists():
                    with urllib.request.urlopen(url, timeout=60) as response:
                        local.write_bytes(response.read())
                if filename.endswith('.parquet'):
                    rows = pd.read_parquet(local).to_dict('records')
                else:
                    rows = [json.loads(line) for line in local.read_text().splitlines()]
                for i, row in enumerate(rows):
                    entries.append(dict(config=filename, revision=info['sha'], row_index=i, row=row))
            dump(raw_path, entries)
        assert len(entries) == 30, (name, len(entries))
        seen = set()
        for entry in entries:
            row = entry['row']
            problem = row.get('problem', row.get('question'))
            assert problem and problem not in seen
            seen.add(problem)
            gold = str(int(normalize_final_answer(str(row['answer']))))
            assert 0 <= int(gold) <= 999
            # Match the DAPO instruction on new competition benchmarks.
            content = ('Solve the following math problem step by step. The last line of your response '
                       'should be of the form Answer: $Answer (without quotes) where $Answer is the '
                       'answer to the problem.\n\n' + problem +
                       '\n\nRemember to put your answer on its own line after "Answer:".')
            records.append(dict(dataset=name, id=f"{entry['config']}:{entry['row_index']}",
                                prompt=[dict(role='user', content=content)], gold=gold,
                                raw_gold=str(row['answer'])))
        sources[name] = 'https://huggingface.co/datasets/' + source
    train = pd.read_parquet(manifest['train_files'])
    train_prompts = {row[0]['content'] for row in train['prompt']}
    for row in records:
        row['prompt_token_ids'] = normalize_token_ids(tokenizer.apply_chat_template(
            row['prompt'], add_generation_prompt=True, enable_thinking=True))
        row['prompt_text'] = tokenizer.decode(row['prompt_token_ids'], skip_special_tokens=True)
        row['exact_training_prompt_overlap'] = row['prompt'][0]['content'] in train_prompts
    assert sum(r['dataset'] == 'dapo_holdout' for r in records) == 128
    assert not any(r['exact_training_prompt_overlap'] for r in records if r['dataset'] == 'dapo_holdout')
    out = ROOT / 'prompts.jsonl'
    temporary = ROOT / 'prompts.jsonl.tmp'
    with temporary.open('w') as stream:
        for row in records:
            stream.write(json.dumps(row, ensure_ascii=False) + '\n')
    if out.exists() and out.stat().st_size:
        assert temporary.read_bytes() == out.read_bytes(), 'Existing evaluation data differ'
        temporary.unlink()
    else:
        temporary.replace(out)
    protocol = dict(actor=manifest['actor'], checkpoints=[0, 5, 10, 15], physical_gpus=[4, 7],
                    sources=sources, dataset_counts={name: sum(r['dataset'] == name for r in records)
                    for name in ['dapo_holdout', 'math500', 'aime2024', 'aime2025']},
                    sampling=dict(temperature=1.0, top_p=1.0, top_k=-1, min_p=0.0, n=16, seed=42,
                                  max_tokens=8192, prefix_diagnostic_tokens=2048,
                                  seed_formula='42 + prompt_index * 16 + sample_index',
                                  repetition_penalty=1.0, presence_penalty=0.0,
                                  frequency_penalty=0.0, ignore_eos=False),
                    inference=dict(tensor_parallel_size=1, dtype='bfloat16', max_model_len=32768,
                                   max_num_seqs=32, max_num_batched_tokens=8192, gpu_memory_utilization=0.65,
                                   enforce_eager=True, enable_prefix_caching=False, generation_config='auto'),
                    chat_template=dict(add_generation_prompt=True, enable_thinking=True),
                    prompts_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),
                    max_prompt_tokens=max(len(r['prompt_token_ids']) for r in records),
                    notes=['16 independent responses per prompt; average accuracy and pass@16.',
                           '2048-token scores are prefix diagnostics of the SAME samples, not independent generations.',
                           'Original MATH100 also reported separately.',
                           'Checkpoint15 interrupted during optimizer save; inference weights validated separately.',
                           'AIME gold numeric leading zeros normalized; identical prompts across checkpoints.',
                           'Exact prompt overlap check cannot establish semantic training contamination.'])
    dump(ROOT / 'protocol.json', protocol)
    print(json.dumps(protocol, indent=2), flush=True)


def export(step, run=None, name=None):
    import torch
    from safetensors import safe_open
    from verl.model_merger.base_model_merger import ModelMergerConfig
    from verl.model_merger.fsdp_model_merger import FSDPModelMerger
    from verl.model_merger.output_validation import validate_hf_model_output

    run = Path(run).resolve() if run else RUN
    label = name or f'step_{step}'
    actor = run / 'checkpoints' / f'global_step_{step}' / 'actor'
    target = ROOT / 'models' / label
    stage = ROOT / 'export_inputs' / label
    stage.mkdir(parents=True, exist_ok=True)
    metadata = RUN / 'checkpoints/global_step_10/actor'
    recovery = run == RUN and step == 15
    if not recovery:
        metadata = actor
    world_size = json.loads((metadata / 'fsdp_config.json').read_text())['world_size']
    for rank in range(world_size):
        source = actor / f'model_world_size_{world_size}_rank_{rank}.pt'
        assert source.is_file()
        destination = stage / source.name
        if not destination.exists():
            destination.symlink_to(source)
    for name in ['fsdp_config.json', 'huggingface']:
        destination = stage / name
        if not destination.exists():
            destination.symlink_to(metadata / name)
    config = ModelMergerConfig(operation='merge', backend='fsdp', local_dir=str(stage),
                              target_dir=str(target), hf_model_config_path=str(stage / 'huggingface'),
                              use_cpu_initialization=True)
    if not (target / 'EXPORT_VALIDATED.json').exists():
        FSDPModelMerger(config).merge_and_save()
        validate_hf_model_output(target)
        entries = 0
        for shard in target.glob('*.safetensors'):
            with safe_open(str(shard), framework='pt', device='cpu') as weights:
                for key in weights.keys():
                    tensor = weights.get_tensor(key)
                    assert torch.isfinite(tensor).all(), key
                    entries += 1
        dump(target / 'EXPORT_VALIDATED.json', dict(step=step, source=str(actor), tensor_count=entries,
                                                  all_finite=True, inference_only_recovery=recovery,
                                                  metadata_source=str(metadata)))
    def shapes(directory):
        result = {}
        for shard in directory.glob('*.safetensors'):
            with safe_open(str(shard), framework='pt') as weights:
                for key in weights.keys():
                    assert key not in result
                    result[key] = list(weights.get_slice(key).get_shape())
        return result
    base = Path(json.loads((ROOT / 'protocol.json').read_text())['actor'])
    expected = shapes(base)
    assert shapes(target) == expected, f'Exported keys or tensor shapes differ: {label}'
    record = json.loads((target / 'EXPORT_VALIDATED.json').read_text())
    record.update(all_keys_and_shapes_match_base=True, expected_tensor_count=len(expected))
    dump(target / 'EXPORT_VALIDATED.json', record)
    print('Export validated:', step, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--export', type=int)
    parser.add_argument('--run')
    parser.add_argument('--name')
    args = parser.parse_args()
    if args.export is not None:
        export(args.export, args.run, args.name)
    else:
        prepare_data()
