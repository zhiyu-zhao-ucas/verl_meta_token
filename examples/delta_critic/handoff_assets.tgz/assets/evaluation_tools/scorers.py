"""Independent repository scorers plus an explicit-answer format diagnostic."""
import re


def extract_final(text):
    from verl.utils.reward_score.math_dapo import last_boxed_only_string, remove_boxed
    box = last_boxed_only_string(text)
    box_position = text.rfind(box) if box else -1
    pattern = (r'(?im)^[ \t]*(?:#{1,6}[ \t]+)?(?:\*{1,2})?'
               r'(?:the[ \t]+)?(?:final[ \t]+)?answer(?:\*{1,2})?[ \t]*'
               r'(?::|is\b[ \t]*:?|(?=\n|$))(?:\*{1,2})?[ \t]*([^\n]*)')
    fields = list(re.finditer(pattern, text))
    field = fields[-1] if fields else None
    if box and (field is None or box_position > field.start()):
        return remove_boxed(box), 'boxed'
    if field:
        tail = (field.group(1) + text[field.end():]).strip()
        if tail.startswith('```'):
            match = re.match(r'```[^\n]*\n(.*?)\n[ \t]*```', tail, flags=re.S)
            return (match.group(1).strip(), 'answer_code_fence') if match else (None, 'incomplete_code_fence')
        for opening, closing in [(r'\[', r'\]'), (r'\(', r'\)'), ('$$', '$$'), ('$', '$')]:
            if tail.startswith(opening):
                end = tail.find(closing, len(opening))
                return (tail[len(opening):end].strip(), 'answer_math') if end >= 0 else (None, 'incomplete_math')
        first = tail.splitlines()[0].strip().strip('*').strip() if tail else ''
        return (first or None), 'answer_line'
    return None, 'missing_explicit_final'


def canonical_score(text, gold):
    # This is the same routine used by the repository math_verify CPU workers.
    # Our ProcessPool invokes it on a main thread, where signal timeouts work.
    from verl.utils.reward_score.math_verify import _verify_in_subprocess
    return float(_verify_in_subprocess(r'\boxed{' + str(gold) + '}', text))


def score_output(text, gold):
    from examples.delta_critic.sampling_io import score_text
    from verl.utils.reward_score.math_dapo import compute_score as dapo_score
    from verl.utils.reward_score.math_reward import compute_score as boxed_score
    errors = {}
    def checked(name, fn):
        try:
            return float(fn())
        except Exception as exc:
            errors[name] = f'{type(exc).__name__}: {exc}'
            return 0.0
    answer, extraction = extract_final(text)
    scores = {
        'repository_math_verify': checked('repository_math_verify', lambda: canonical_score(text, gold)),
        'repository_math_dapo': checked('repository_math_dapo', lambda: bool(dapo_score(text, gold)['acc'])),
        'repository_math_reward': checked('repository_math_reward', lambda: boxed_score(text, gold)),
        'explicit_final_math_verify': checked('explicit_final_math_verify',
            lambda: canonical_score(r'\boxed{' + answer + '}', gold) if answer else 0.0),
        'training_compatible': checked('training_compatible',
            lambda: score_text(text, str(gold), {'method': 'math_verify', 'fallback_on_import_error': False})),
    }
    return dict(scores=scores, extracted_final=answer, extraction=extraction, scorer_errors=errors,
                scoring_disagreement=len(set(scores.values())) > 1)


def offline_repository_math_verify(data_source, response, ground_truth, **kwargs):
    from verl.utils.reward_score.math_verify import compute_score
    return float(compute_score(response, str(ground_truth)))


def offline_explicit_final(data_source, response, ground_truth, **kwargs):
    from verl.utils.reward_score.math_verify import compute_score
    answer, _ = extract_final(response)
    return float(compute_score(r'\boxed{' + answer + '}', str(ground_truth))) if answer else 0.0


if __name__ == '__main__':
    tests = [
        (r'\boxed{42}', '42', 1),
        ('**Final Answer:**\n```\n42\n```', '42', 1),
        (r'\boxed{42}' + '\nAnswer: 63', '42', 0),
        ('The problem mentions 42.\nAnswer: 63', '42', 0),
        ('Compute 42 minus 1.', '42', 0),
        (r'\boxed{\frac{1}{2}}', '0.5', 1),
        ('Answer: 042', '42', 1),
        ('### Final Answer\n\\[42\\]', '42', 1),
        ('**Final Answer:**\n```\n63\n```', '42', 0),
    ]
    for text, gold, expected in tests:
        result = score_output(text, gold)
        assert result['scores']['explicit_final_math_verify'] == expected, (text, result)
        assert not result['scorer_errors'], result
    print(f'{len(tests)} explicit-answer and adversarial verifier checks passed', flush=True)
